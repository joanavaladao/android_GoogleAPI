package com.valadao.joana.mylocation2;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.SupportMapFragment;

import java.io.File;
import java.util.List;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements
        GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {

    // Photo Properties
    String pathPhoto;
    File filePhoto;
    static final int REQUEST_IMAGE_CAPTURE = 567;

    // LOCATION
    GoogleApiClient googleApiClient;
    Location lastLocation;
    Double actualLatitude, actualLongitude, photoLatitude, photoLongitude;
    String address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //initializing properties
        pathPhoto = getExternalFilesDir(null) + "/photo.jpg";
        filePhoto = new File(pathPhoto);

        // Taking Photo
        ImageButton buttonPhoto = (ImageButton) findViewById(R.id.button_photo);
        buttonPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                intentCamera.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(filePhoto));
                startActivityForResult(intentCamera, REQUEST_IMAGE_CAPTURE);
                photoLatitude = actualLatitude;
                photoLongitude = actualLongitude;
            }
        });


        // LOCATION
        // Create an instance of GoogleAPIClient.
        if (googleApiClient == null) {
            googleApiClient = new GoogleApiClient.Builder(this)
                    .addConnectionCallbacks((GoogleApiClient.ConnectionCallbacks) this)
                    .addOnConnectionFailedListener((GoogleApiClient.OnConnectionFailedListener) this)
                    .addApi(LocationServices.API)
                    .build();
        }
        if (googleApiClient != null) {
//            Toast.makeText(MainActivity.this, "chamei connect", Toast.LENGTH_SHORT).show();
            googleApiClient.connect();

        }

        ImageButton btnMap = (ImageButton) findViewById(R.id.button_map);
        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                MyMapFragment mapFragment = new MyMapFragment();
                Bundle location = new Bundle();
                location.putDouble("latitude", photoLatitude);
                location.putDouble("longitude", photoLongitude);
                mapFragment.setArguments(location);
                fragmentTransaction.replace(R.id.fragment_map, mapFragment);
                fragmentTransaction.commit();
            }
        });




    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        System.out.println("entrei no activity result");
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            ImageView photo = (ImageView) findViewById(R.id.imageView);
            Bitmap bitmap = BitmapFactory.decodeFile(pathPhoto);
            Bitmap smallBitmap = Bitmap.createScaledBitmap(bitmap, 300, 300, true);
            photo.setScaleType(ImageView.ScaleType.FIT_XY);
            photo.setImageBitmap(smallBitmap);

//            photoLatitude = 43.642701;
//            photoLongitude = -79.386669;

//            getAddress(photoLatitude, photoLongitude);

        }
    }


    /*****************************************************
     * LOCATION
     */
    // connecting when the application starts
    protected void onStart() {
        googleApiClient.connect();
        super.onStart();
    }

    // disconnecting when the application ends
    protected void onStop() {
        googleApiClient.disconnect();
        super.onStop();
    }

    // getting the location
    @Override
    public void onConnected(Bundle connectionHint) {
//        Toast.makeText(MainActivity.this, "entrei no onConnected", Toast.LENGTH_LONG).show();
//        Toast.makeText(MainActivity.this, "permission granted = " + ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION), Toast.LENGTH_LONG).show();
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            Toast.makeText(MainActivity.this, "Please, give permission to app access the location. This is to show you where the picture was taken.", Toast.LENGTH_LONG).show();
            return;
        }

        lastLocation = LocationServices.FusedLocationApi.getLastLocation(googleApiClient);
        if (lastLocation != null) {
            actualLatitude = lastLocation.getLatitude();
            actualLongitude = lastLocation.getLongitude();
//            Toast.makeText(MainActivity.this, "latitude = "+actualLatitude+" longitude = "+actualLongitude, Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(MainActivity.this, "Impossible to get the location", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Toast.makeText(MainActivity.this, "Impossible to connect and get the location", Toast.LENGTH_LONG).show();
    }

    protected void createLocationRequest() {
        LocationRequest locationRequest = new LocationRequest();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
    }

    @Override
    public void onLocationChanged(Location location) {
        actualLatitude = location.getLatitude();
        actualLongitude = location.getLongitude();
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopLocationUpdates();
    }

    protected void stopLocationUpdates() {
        LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, this);
    }


    public void getAddress(double latitude, double longitude){
        try {
            Geocoder geo = new Geocoder(MainActivity.this.getApplicationContext(), Locale.getDefault());
            List<Address> addresses = geo.getFromLocation(latitude, longitude, 1);
            if (addresses.isEmpty()) {
                Toast.makeText(MainActivity.this, "Waiting for the address", Toast.LENGTH_LONG).show();
            }
            else {
                if (addresses.size() > 0) {
                    address = addresses.get(0).getFeatureName() + ", " + addresses.get(0).getLocality() +", " + addresses.get(0).getAdminArea() + ", " + addresses.get(0).getCountryName();
//                    Toast.makeText(MainActivity.this, address, Toast.LENGTH_LONG).show();
                    //Toast.makeText(getApplicationContext(), "Address:- " + addresses.get(0).getFeatureName() + addresses.get(0).getAdminArea() + addresses.get(0).getLocality(), Toast.LENGTH_LONG).show();
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace(); // getFromLocation() may sometimes fail
        }
    }
}
