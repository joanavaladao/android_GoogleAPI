package com.valadao.joana.mylocation2;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

/**
 * Created by Joana on 27/04/17.
 */

public class MyMapFragment extends SupportMapFragment implements OnMapReadyCallback {

    Double latitude, longitude;


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        latitude = getArguments().getDouble("latitude");
        longitude = getArguments().getDouble("longitude");

        getMapAsync(this);
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        if (latitude != null && longitude != null) {
            LatLng latLong = new LatLng(latitude, longitude);
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLong, 17);
            googleMap.moveCamera(cameraUpdate);

            // adding the pin
            MarkerOptions pin = new MarkerOptions();
            pin.position(latLong);
            googleMap.addMarker(pin);
        }
    }
}
